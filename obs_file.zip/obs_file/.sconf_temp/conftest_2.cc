
    #include <stdint.h>
    void test(long long v) { }
    void test(int64_t v) { }
    int main() { return 0; }
    