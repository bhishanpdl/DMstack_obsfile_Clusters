#!/usr/bin/env python
from lsst.pipe.tasks.ingest import IngestTask
IngestTask.parseAndRun()