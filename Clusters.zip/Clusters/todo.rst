- Data

  - Complete the doc

- Extinction

  - Plug the Extinction package in and remove all internal extinction-related code
