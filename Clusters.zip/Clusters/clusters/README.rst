See the `online documentation <http://clusters.readthedocs.io/en/latest/>`_ for detail on what is done. Here are direct links to each (available) subsections:

- `Data format <http://clusters.readthedocs.io/en/latest/data.html>`_
