#!/usr/bin/env python
"""Get a cluster background galaxies."""

import sys
from clusters.mains import background

sys.exit(background.getbackground())
