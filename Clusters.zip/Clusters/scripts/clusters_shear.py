#!/usr/bin/env python
"""Shear analysis."""

import sys
from clusters.mains import shear

sys.exit(shear.shear())
