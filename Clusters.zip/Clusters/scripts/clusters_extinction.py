#!/usr/bin/env python
"""Load the color excess."""

import sys
from clusters.mains import extinction

sys.exit(extinction.extinction())
