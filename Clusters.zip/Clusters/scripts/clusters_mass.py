#!/usr/bin/env python
"""Mass analysis."""

import sys
from clusters.mains import mass

sys.exit(mass.mass())
