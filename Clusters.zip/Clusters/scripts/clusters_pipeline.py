#!/usr/bin/env python
"""Pipeline for standard cluster analysis."""

import sys
from clusters.mains import pipeline

sys.exit(pipeline.pipeline())
