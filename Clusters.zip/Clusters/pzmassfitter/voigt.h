#ifndef __VOIGT_H__
#define __VOIGT_H__

#include <math.h>



double voigt(double xx, double sigma, double lg);



#endif
