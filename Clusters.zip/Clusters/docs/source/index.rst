.. Clusters documentation master file, created by
   sphinx-quickstart on Thu Aug  4 12:06:33 2016.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Welcome to Clusters's documentation!
====================================

.. warning:: Package under development
  
.. toctree::
   :maxdepth: 2

   readme

.. toctree::
   :maxdepth: 2

   data
   
.. toctree::
   :maxdepth: 2

   validation

.. toctree::
   :maxdepth: 2

   extinction

.. toctree::
   :maxdepth: 2

   photoz

.. toctree::
   :maxdepth: 2

   selection

.. toctree::
   :maxdepth: 2

   shear

.. toctree::
   :maxdepth: 2

   mass

.. toctree::
   :maxdepth: 2

   modules

.. toctree::
   :maxdepth: 2

   todo
