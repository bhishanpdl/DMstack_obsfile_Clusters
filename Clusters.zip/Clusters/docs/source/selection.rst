Galaxy selection
================

Write the doc
