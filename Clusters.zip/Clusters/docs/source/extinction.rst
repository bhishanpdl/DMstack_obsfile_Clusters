Extinction
==========

Write the doc
